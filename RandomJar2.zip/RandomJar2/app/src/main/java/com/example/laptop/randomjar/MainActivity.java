package com.example.laptop.randomjar;

// shows food in list view when clicked outputs item clicked
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.app.ListActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.Random;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button randomButton = (Button)findViewById(R.id.randomButton);
        ArrayAdapter<String> adapter;
        String[] mTestArray = getResources().getStringArray(R.array.testArray);
        String randomString = mTestArray[new Random().nextInt(mTestArray.length)];

        adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, mTestArray);
        ListView myListView = (ListView) findViewById(R.id.myListView);
        myListView.setAdapter(adapter);

        myListView.setOnItemClickListener(
                new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                        String food = String.valueOf(parent.getItemAtPosition(position));
                        Toast.makeText(MainActivity.this, food, Toast.LENGTH_LONG).show();
                    }
                }
        ); 

    }
}





